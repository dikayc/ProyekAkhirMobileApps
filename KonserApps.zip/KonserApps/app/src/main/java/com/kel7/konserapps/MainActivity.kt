package com.kel7.konserapps

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class MainActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val cvVIP: CardView = findViewById(R.id.cvVIP)
        val cvPremium: CardView = findViewById(R.id.cvPremium)
        val cvRegular: CardView = findViewById(R.id.cvRegular)
        val cvCart: ImageButton = findViewById(R.id.Cart)
        val cvMaps: ImageButton = findViewById(R.id.Maps)

        cvMaps.setOnClickListener (this)
        cvCart.setOnClickListener (this)
        cvVIP.setOnClickListener(this)
        cvPremium.setOnClickListener(this)
        cvRegular.setOnClickListener(this)

        // hiding the action bar
        supportActionBar!!.hide()
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.cvVIP -> {
                val moveIntent = Intent(this@MainActivity, VipActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.cvPremium -> {
                val moveIntent = Intent(this@MainActivity, PremiumActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.cvRegular -> {
                val moveIntent = Intent(this@MainActivity, RegularActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.Maps -> {
                val moveIntent = Intent(this@MainActivity, StageActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.Cart -> {
                val moveIntent = Intent(this@MainActivity, KeranjangActivity::class.java)
                startActivity(moveIntent)
            }
        }
    }
}
