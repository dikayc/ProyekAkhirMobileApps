package com.kel7.konserapps

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class VipActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vip)
        supportActionBar!!.hide()
    }}