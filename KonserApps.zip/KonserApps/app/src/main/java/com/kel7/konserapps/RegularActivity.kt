package com.kel7.konserapps

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class RegularActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_regular)
        supportActionBar!!.hide()
    }
}