package com.kel7.konserapps


import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class StageActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stage)

        supportActionBar!!.hide()
    }
}